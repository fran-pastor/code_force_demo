package bikeapplication.bike.controller;

import bikeapplication.bike.entities.Bike;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
public class BikeControllerE2E {

    @Container
    public static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15.3")
            .withDatabaseName("testdb")
            .withUsername("test")
            .withPassword("test");

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private String baseUrl() {
        return "http://localhost:" + port + "/bike";
    }

    private Bike createTestBike() {
        Bike bike = new Bike();
        bike.setOwnName("E2E User");
        bike.setMobile("9876543210");
        bike.setBikeNo("E2E" + System.currentTimeMillis());
        bike.setBrand("Honda");
        bike.setModel("CBR");
        bike.setDateOfAppointment("2024-06-15");
        bike.setDescription("E2E test bike");
        return bike;
    }

    private Bike createBikeOnServer() {
        Bike bike = createTestBike();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Bike> request = new HttpEntity<>(bike, headers);
        ResponseEntity<Bike> response = restTemplate.postForEntity(baseUrl(), request, Bike.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        return response.getBody();
    }

    @Test
    public void testCreateBike_HappyPath() {
        Bike bike = createTestBike();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Bike> request = new HttpEntity<>(bike, headers);

        ResponseEntity<Bike> response = restTemplate.postForEntity(baseUrl(), request, Bike.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        Bike createdBike = response.getBody();
        assertThat(createdBike).isNotNull();
        assertThat(createdBike.getOwnName()).isEqualTo(bike.getOwnName());
        assertThat(createdBike.getBikeNo()).isEqualTo(bike.getBikeNo());
    }

    @Test
    public void testGetBikeById_HappyPath() {
        Bike createdBike = createBikeOnServer();

        ResponseEntity<Bike> response = restTemplate.getForEntity(baseUrl() + "/" + createdBike.getBikeId(), Bike.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        Bike bike = response.getBody();
        assertThat(bike).isNotNull();
        assertThat(bike.getBikeId()).isEqualTo(createdBike.getBikeId());
    }

    @Test
    public void testGetBikeById_NotFound() {
        ResponseEntity<String> response = restTemplate.getForEntity(baseUrl() + "/nonexistentid", String.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void testUpdateBike_HappyPath() {
        Bike createdBike = createBikeOnServer();

        Bike update = new Bike();
        update.setOwnName("Updated E2E User");
        update.setMobile("1112223333");
        update.setBikeNo(createdBike.getBikeNo());
        update.setBrand("Honda");
        update.setModel("CBR Updated");
        update.setDateOfAppointment("2024-06-20");
        update.setDescription("Updated description");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Bike> request = new HttpEntity<>(update, headers);

        ResponseEntity<Bike> response = restTemplate.exchange(baseUrl() + "/" + createdBike.getBikeId(), HttpMethod.PUT, request, Bike.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        Bike updatedBike = response.getBody();
        assertThat(updatedBike).isNotNull();
        assertThat(updatedBike.getOwnName()).isEqualTo("Updated E2E User");
        assertThat(updatedBike.getModel()).isEqualTo("CBR Updated");
    }

    @Test
    public void testUpdateBike_NotFound() {
        Bike update = createTestBike();
        update.setOwnName("Nonexistent");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Bike> request = new HttpEntity<>(update, headers);

        ResponseEntity<String> response = restTemplate.exchange(baseUrl() + "/nonexistentid", HttpMethod.PUT, request, String.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void testGetAllBike_HappyPath() {
        createBikeOnServer();

        ResponseEntity<Bike[]> response = restTemplate.getForEntity(baseUrl(), Bike[].class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        Bike[] bikes = response.getBody();
        assertThat(bikes).isNotNull();
        assertThat(bikes.length).isGreaterThan(0);
    }

    @Test
    public void testGetBikesInProcess_HappyPath() {
        ResponseEntity<Bike[]> response = restTemplate.getForEntity(baseUrl() + "/in_process", Bike[].class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testGetSuccess_HappyPath() {
        ResponseEntity<Bike[]> response = restTemplate.getForEntity(baseUrl() + "/success", Bike[].class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testGetHandOvered_HappyPath() {
        ResponseEntity<Bike[]> response = restTemplate.getForEntity(baseUrl() + "/handover", Bike[].class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testHandoverFalse_HappyPath() {
        ResponseEntity<Bike[]> response = restTemplate.getForEntity(baseUrl() + "/!handover", Bike[].class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testTodayAppoint_HappyPath() {
        ResponseEntity<Bike[]> response = restTemplate.getForEntity(baseUrl() + "/today", Bike[].class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testGetBikeStatus_HappyPath() {
        Bike createdBike = createBikeOnServer();
        ResponseEntity<String> response = restTemplate.getForEntity(baseUrl() + "/status/" + createdBike.getBikeNo(), String.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testGetBikeStatus_NotFound() {
        ResponseEntity<String> response = restTemplate.getForEntity(baseUrl() + "/status/INVALIDBIKENO", String.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void testUpdateStatus_HappyPath() {
        Bike createdBike = createBikeOnServer();
        ResponseEntity<Void> response = restTemplate.getForEntity(baseUrl() + "/update/process/" + createdBike.getBikeId(), Void.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    public void testUpdateStatus_NotFound() {
        ResponseEntity<Void> response = restTemplate.getForEntity(baseUrl() + "/update/process/nonexistentid", Void.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void testDeleteBike_HappyPath() {
        Bike createdBike = createBikeOnServer();
        ResponseEntity<Void> response = restTemplate.exchange(baseUrl() + "/" + createdBike.getBikeId(), HttpMethod.DELETE, null, Void.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
    }

    @Test
    public void testDeleteBike_NotFound() {
        ResponseEntity<Void> response = restTemplate.exchange(baseUrl() + "/nonexistentid", HttpMethod.DELETE, null, Void.class);
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    public void testCreateBike_BadRequest() {
        Bike bike = new Bike(); // empty bike, missing required fields

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Bike> request = new HttpEntity<>(bike, headers);

        ResponseEntity<String> response = restTemplate.postForEntity(baseUrl(), request, String.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }

}