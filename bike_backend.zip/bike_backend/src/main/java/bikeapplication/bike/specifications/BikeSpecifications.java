package bikeapplication.bike.specifications;

import bikeapplication.bike.dto.BikeSearchCriteria;
import bikeapplication.bike.entities.Bike;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

public final class BikeSpecifications {

    private static final List<String> FULL_TEXT_FIELDS = List.of("ownName", "bikeNo", "brand", "model", "status");

    private BikeSpecifications() {
    }

    public static Specification<Bike> build(BikeSearchCriteria criteria) {
        return (root, query, cb) -> {
            if (criteria == null) {
                return cb.conjunction();
            }
            List<Predicate> predicates = new ArrayList<>();

            addFullTextFilter(criteria.getQ(), root, cb, predicates);
            addTextFilter(criteria.getOwnName(), "ownName", root, cb, predicates);
            addTextFilter(criteria.getBikeNo(), "bikeNo", root, cb, predicates);
            addTextFilter(criteria.getBrand(), "brand", root, cb, predicates);
            addTextFilter(criteria.getModel(), "model", root, cb, predicates);

            addBooleanFilter(criteria.getInProcess(), "inProcess", root, cb, predicates);
            addBooleanFilter(criteria.getSuccess(), "success", root, cb, predicates);
            addBooleanFilter(criteria.getHandOver(), "isHandOver", root, cb, predicates);

            addDateRange(criteria.getDateFrom(), root, cb, predicates, true);
            addDateRange(criteria.getDateTo(), root, cb, predicates, false);

            if (predicates.isEmpty()) {
                return cb.conjunction();
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }

    private static void addFullTextFilter(String value,
                                          Root<Bike> root,
                                          CriteriaBuilder cb,
                                          List<Predicate> predicates) {
        if (!StringUtils.hasText(value)) {
            return;
        }
        String pattern = "%" + value.trim().toLowerCase() + "%";
        List<Predicate> orPredicates = new ArrayList<>();
        for (String field : FULL_TEXT_FIELDS) {
            Expression<String> expression = cb.lower(root.get(field));
            orPredicates.add(cb.like(expression, pattern));
        }
        predicates.add(cb.or(orPredicates.toArray(new Predicate[0])));
    }

    private static void addTextFilter(String value,
                                      String field,
                                      Root<Bike> root,
                                      CriteriaBuilder cb,
                                      List<Predicate> predicates) {
        if (!StringUtils.hasText(value)) {
            return;
        }
        String pattern = "%" + value.trim().toLowerCase() + "%";
        Expression<String> expression = cb.lower(root.get(field));
        predicates.add(cb.like(expression, pattern));
    }

    private static void addBooleanFilter(Boolean value,
                                         String field,
                                         Root<Bike> root,
                                         CriteriaBuilder cb,
                                         List<Predicate> predicates) {
        if (value == null) {
            return;
        }
        predicates.add(cb.equal(root.get(field), value));
    }

    private static void addDateRange(String value,
                                     Root<Bike> root,
                                     CriteriaBuilder cb,
                                     List<Predicate> predicates,
                                     boolean isFrom) {
        if (!StringUtils.hasText(value)) {
            return;
        }
        String cleaned = value.trim();
        if (isFrom) {
            predicates.add(cb.greaterThanOrEqualTo(root.get("dateOfAppointment"), cleaned));
        } else {
            predicates.add(cb.lessThanOrEqualTo(root.get("dateOfAppointment"), cleaned));
        }
    }
}