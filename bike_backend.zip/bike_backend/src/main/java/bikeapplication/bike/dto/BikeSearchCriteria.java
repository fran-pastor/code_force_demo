package bikeapplication.bike.dto;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class BikeSearchCriteria {

    @Size(max = 100)
    private String q;

    @Size(max = 60)
    private String ownName;

    @Size(max = 40)
    private String bikeNo;

    @Size(max = 60)
    private String brand;

    @Size(max = 60)
    private String model;

    @Size(max = 40)
    private String status;

    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Invalid date format. Use yyyy-MM-dd")
    private String dateFrom;

    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "Invalid date format. Use yyyy-MM-dd")
    private String dateTo;

    private Boolean inProcess;
    private Boolean success;
    private Boolean handOver;
}