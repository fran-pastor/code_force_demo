package bikeapplication.bike.repositories;

import bikeapplication.bike.entities.Bike;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BikeRepositories extends JpaRepository<Bike, String> {

    List<Bike> findByBikeNo(String bikeNo);

    List<Bike> findByOwnName(String ownName);

    List<Bike> findByInProcessTrue();

    List<Bike> findBySuccessTrue();

    List<Bike> findByIsHandOverFalse();

    List<Bike> findByIsHandOverTrue();

}