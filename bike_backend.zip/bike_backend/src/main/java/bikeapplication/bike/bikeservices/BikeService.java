package bikeapplication.bike.bikeservices;

import bikeapplication.bike.entities.Bike;

import java.util.List;

public interface BikeService {

    Bike bookBike(Bike bike);

    Bike update(String bikeId, Bike bike);

    List<Bike> getAll();

    List<Bike> getByNo(String bikeNo);

    List<Bike> getByCurrentDate();

    List<Bike> getByOwnName(String ownName);

    List<Bike> getByInProcess();

    List<Bike> getSuccess();

    List<Bike> getNotHandOver();

    List<Bike> getHandOverBike();

    String getStatus(String bikeNo);

    void updateStatus(String statusType, String bikeNo);

    void update(String statusType, String bikeId);

    Bike getById(String bikeId);

    void deleteById(String bikeId);

}