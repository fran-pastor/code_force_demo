package bikeapplication.bike.bikeservices.bikeservicesimpl;

import bikeapplication.bike.bikeservices.BikeService;
import bikeapplication.bike.repositories.BikeRepositories;
import bikeapplication.bike.entities.Bike;
import bikeapplication.bike.exceptions.BikeNotFoundException;

import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class BikeServiceImpl implements BikeService {

    private final BikeRepositories bikeRepositories;

    private static final String BIKE_NOT_FOUND_MSG = "bike not found for given bikeId !!";

    public BikeServiceImpl(BikeRepositories bikeRepositories) {
        this.bikeRepositories = bikeRepositories;
    }

    @Override
    public Bike bookBike(Bike bike) {
        return bikeRepositories.save(bike);
    }

    @Override
    public Bike update(String bikeId, Bike bike) {
        Bike existingBike = bikeRepositories.findById(bikeId).orElseThrow(
                () -> new BikeNotFoundException(BIKE_NOT_FOUND_MSG));

        existingBike.setOwnName(bike.getOwnName());
        existingBike.setMobile(bike.getMobile());
        existingBike.setBikeNo(bike.getBikeNo());
        existingBike.setBrand(bike.getBrand());
        existingBike.setModel(bike.getModel());
        existingBike.setDateOfAppointment(bike.getDateOfAppointment());
        existingBike.setDescription(bike.getDescription());
        existingBike.setInProcess(bike.isInProcess());
        existingBike.setSuccess(bike.isSuccess());
        existingBike.setStatus(bike.getStatus());
        existingBike.setHandOver(bike.isHandOver());

        return bikeRepositories.save(existingBike);
    }

    @Override
    public List<Bike> getAll() {
        return bikeRepositories.findAll();
    }

    @Override
    public List<Bike> getByNo(String bikeNo) {
        return bikeRepositories.findByBikeNo(bikeNo);
    }

    private static final String BIKE_DELIVERED_MSG = "bike is delivered !! thank you for visiting !!";
    private static final String BIKE_SERVICED_MSG = "bikes servicing completed !! thank you for visiting !!";
    private static final String BIKE_IN_PROCESS_MSG = "bike is in process";
    private static final String BIKE_WAIT_MSG = "give us 3 working days";
    private static final String BIKE_NOT_FOUND_MSG_BIKE_NO = "bike is not found for given bike Number please enter details again !!";

    @Override
    public List<Bike> getByCurrentDate() {
        LocalDateTime date = LocalDateTime.now();
        String currDate = String.format("%04d-%02d-%02d", date.getYear(), date.getMonthValue(), date.getDayOfMonth());

        List<Bike> bikes = bikeRepositories.findAll();
        List<Bike> filteredBikes = new ArrayList<>();

        for (Bike bike : bikes) {
            if (currDate.equalsIgnoreCase(bike.getDateOfAppointment())
                    && !(bike.isInProcess() || bike.isSuccess() || bike.isHandOver())) {
                filteredBikes.add(bike);
            }
        }
        return filteredBikes;
    }

    @Override
    public List<Bike> getByOwnName(String ownName) {
        return bikeRepositories.findByOwnName(ownName);
    }

    @Override
    public List<Bike> getByInProcess() {
        return bikeRepositories.findByInProcessTrue();
    }

    @Override
    public List<Bike> getSuccess() {
        return bikeRepositories.findBySuccessTrue();
    }

    @Override
    public List<Bike> getNotHandOver() {
       return bikeRepositories.findByIsHandOverFalse();
    }

    @Override
    public List<Bike> getHandOverBike() {
        return bikeRepositories.findByIsHandOverTrue();
    }

    @Override
    public String getStatus(String bikeNo) {
        List<Bike> bikes = bikeRepositories.findAll();
        for (Bike bike : bikes) {
            if (bike.getBikeNo().equalsIgnoreCase(bikeNo)) {
                if (bike.isHandOver()) return BIKE_DELIVERED_MSG;
                else if (bike.isSuccess()) return BIKE_SERVICED_MSG;
                else if (bike.isInProcess()) return BIKE_IN_PROCESS_MSG;
                else return BIKE_WAIT_MSG;
            }
        }
        return BIKE_NOT_FOUND_MSG_BIKE_NO;
    }

    @Override
    public void updateStatus(String statusType, String bikeNo) {
        List<Bike> bikes = bikeRepositories.findAll();

        for (Bike bike : bikes) {
            if (bike.getBikeNo().equalsIgnoreCase(bikeNo)) {
                if (statusType.equalsIgnoreCase("process")) {
                    bike.setInProcess(true);
                    bikeRepositories.save(bike);
                } else if (statusType.equalsIgnoreCase("success")) {
                    bike.setSuccess(true);
                    bike.setInProcess(false);
                    bikeRepositories.save(bike);
                } else if (statusType.equalsIgnoreCase("handover")) {
                    bike.setHandOver(true);
                    bike.setSuccess(false);
                    bikeRepositories.save(bike);
                } else if (statusType.equalsIgnoreCase("!process")) {
                    bike.setInProcess(false);
                    bikeRepositories.save(bike);
                } else if (statusType.equalsIgnoreCase("!success")) {
                    bike.setSuccess(false);
                    bikeRepositories.save(bike);
                } else if (statusType.equalsIgnoreCase("!handover")) {
                    bike.setHandOver(false);
                    bikeRepositories.save(bike);
                }
                break;
            }
        }
    }

    @Override
    public void update(String statusType, String bikeId) {
        Bike bike = bikeRepositories.findById(bikeId)
                .orElseThrow(() -> new BikeNotFoundException(BIKE_NOT_FOUND_MSG));

        if (statusType.equalsIgnoreCase("process")) {
            bike.setInProcess(true);
        } else if (statusType.equalsIgnoreCase("success")) {
            bike.setSuccess(true);
            bike.setInProcess(false);
        } else if (statusType.equalsIgnoreCase("handover")) {
            bike.setHandOver(true);
            bike.setSuccess(false);
        } else if (statusType.equalsIgnoreCase("!process")) {
            bike.setInProcess(false);
        } else if (statusType.equalsIgnoreCase("!success")) {
            bike.setSuccess(false);
        } else if (statusType.equalsIgnoreCase("!handover")) {
            bike.setHandOver(false);
        }
        bikeRepositories.save(bike);
    }

    public Bike getById(String bikeId) {
        return bikeRepositories.findById(bikeId)
                .orElseThrow(() -> new BikeNotFoundException(BIKE_NOT_FOUND_MSG));
    }

    @Override
    public void deleteById(String bikeId) {
        Bike bike = bikeRepositories.findById(bikeId)
                .orElseThrow(() -> new BikeNotFoundException(BIKE_NOT_FOUND_MSG));
        bikeRepositories.delete(bike);
    }

}