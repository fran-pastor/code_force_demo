package bikeapplication.bike.specifications;

import bikeapplication.bike.dto.BikeSearchCriteria;
import bikeapplication.bike.entities.Bike;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class BikeSpecificationsTest {

    @Mock
    private Root<Bike> root;

    @Mock
    private CriteriaQuery<?> query;

    @Mock
    private CriteriaBuilder cb;

    @Mock
    private Expression<String> lowerExpression;

    @Mock
    private Predicate andPredicate;

    @Mock
    private Predicate orPredicate;

    @Mock
    private Predicate likePredicate;

    @Mock
    private Predicate booleanPredicate;

    @Mock
    private Predicate greaterPredicate;

    @Mock
    private Predicate lessPredicate;

    @Mock
    private Path<String> ownNamePath;

    @Mock
    private Path<String> bikeNoPath;

    @Mock
    private Path<String> brandPath;

    @Mock
    private Path<String> modelPath;

    @Mock
    private Path<String> statusPath;

    @Mock
    private Path<String> datePath;

    @Mock
    private Path<Boolean> inProcessPath;

    @Mock
    private Path<Boolean> successPath;

    @Mock
    private Path<Boolean> handOverPath;

    @BeforeEach
    void setUp() {
        when(root.get("ownName")).thenReturn((Path) ownNamePath);
        when(root.get("bikeNo")).thenReturn((Path) bikeNoPath);
        when(root.get("brand")).thenReturn((Path) brandPath);
        when(root.get("model")).thenReturn((Path) modelPath);
        when(root.get("status")).thenReturn((Path) statusPath);
        when(root.get("dateOfAppointment")).thenReturn((Path) datePath);
        when(root.get("inProcess")).thenReturn((Path) inProcessPath);
        when(root.get("success")).thenReturn((Path) successPath);
        when(root.get("isHandOver")).thenReturn((Path) handOverPath);

        when(cb.lower(any(Expression.class))).thenReturn(lowerExpression);
        when(cb.like(any(Expression.class), anyString())).thenReturn(likePredicate);
        when(cb.or(any(Predicate[].class))).thenReturn(orPredicate);
        when(cb.and(any(Predicate[].class))).thenReturn(andPredicate);
        when(cb.equal(any(Path.class), any(Boolean.class))).thenReturn(booleanPredicate);
        when(cb.greaterThanOrEqualTo(any(Path.class), anyString())).thenReturn(greaterPredicate);
        when(cb.lessThanOrEqualTo(any(Path.class), anyString())).thenReturn(lessPredicate);
    }

    @Test
    void shouldBuildFullTextSearchPredicates() {
        BikeSearchCriteria criteria = BikeSearchCriteria.builder()
                .q("SearchTerm")
                .build();
        Specification<Bike> spec = BikeSpecifications.build(criteria);

        spec.toPredicate(root, query, cb);

        ArgumentCaptor<String> patternCaptor = ArgumentCaptor.forClass(String.class);
        verify(cb, times(5)).like(any(Expression.class), patternCaptor.capture());
        List<String> captured = patternCaptor.getAllValues();
        assertThat(captured).containsOnly("%searchterm%");
        verify(cb).or(any(Predicate[].class));
        verify(cb).and(any(Predicate[].class));
    }

    @Test
    void shouldBuildTextFiltersForFields() {
        BikeSearchCriteria criteria = BikeSearchCriteria.builder()
                .ownName("Alpha")
                .bikeNo("B001")
                .brand("Yamaha")
                .model("FZ")
                .build();
        Specification<Bike> spec = BikeSpecifications.build(criteria);

        spec.toPredicate(root, query, cb);

        ArgumentCaptor<String> patternCaptor = ArgumentCaptor.forClass(String.class);
        verify(cb, times(4)).like(any(Expression.class), patternCaptor.capture());
        assertThat(patternCaptor.getAllValues())
                .containsExactlyInAnyOrder("%alpha%", "%b001%", "%yamaha%", "%fz%");
        verify(cb).and(any(Predicate[].class));
    }

    @Test
    void shouldBuildBooleanAndDateRangePredicates() {
        BikeSearchCriteria criteria = BikeSearchCriteria.builder()
                .inProcess(true)
                .success(false)
                .handOver(true)
                .dateFrom("2025-01-01")
                .dateTo("2025-01-31")
                .build();
        Specification<Bike> spec = BikeSpecifications.build(criteria);

        spec.toPredicate(root, query, cb);

        verify(cb).equal(inProcessPath, true);
        verify(cb).equal(successPath, false);
        verify(cb).equal(handOverPath, true);
        verify(cb).greaterThanOrEqualTo(datePath, "2025-01-01");
        verify(cb).lessThanOrEqualTo(datePath, "2025-01-31");

        ArgumentCaptor<Predicate[]> captor = ArgumentCaptor.forClass(Predicate[].class);
        verify(cb).and(captor.capture());
        assertThat(captor.getValue()).hasSize(5);
    }
}