package bikeapplication.bike.controller;

import bikeapplication.bike.bikeservices.BikeService;
import bikeapplication.bike.entities.Bike;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Date;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BikeController.class)
class BikeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private BikeService bikeService;

    private Bike bike;

    @BeforeEach
    void setUp() {
        bike = Bike.builder()
                .bikeId("1")
                .ownName("John Doe")
                .mobile("1234567890")
                .bikeNo("BIKE123")
                .brand("Yamaha")
                .model("FZ")
                .bookAt(new Date())
                .dateOfAppointment("2024-06-10")
                .description("Regular servicing")
                .inProcess(false)
                .success(false)
                .status("wait upto 2024-06-10")
                .isHandOver(false)
                .build();
    }

    @Test
    void testCreateBikeMalformedJson() throws Exception {
        String malformedJson = "{\"ownName\":\"John Doe\",\"mobile\":1234567890,\"bikeNo\":\"BIKE123\""; // missing closing brace, mobile not quoted
        mockMvc.perform(post("/bike")
                .contentType(MediaType.APPLICATION_JSON)
                .content(malformedJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Malformed JSON request"));
    }

    @Test
    void testUpdateBikeMalformedJson() throws Exception {
        String malformedJson = "{\"ownName\":\"John Doe\",\"mobile\":1234567890,\"bikeNo\":\"BIKE123\"";
        mockMvc.perform(put("/bike/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(malformedJson))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("Malformed JSON request"));
    }

    @Test
    void testInternalServerError() throws Exception {
        when(bikeService.getById("500")).thenThrow(new RuntimeException("Unexpected error"));
        mockMvc.perform(get("/bike/500"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.error").value("Internal Server Error"));
    }

    @Test
    void testCreateBike() throws Exception {
        when(bikeService.bookBike(any(Bike.class))).thenReturn(bike);

        String bikeJson = "{\"ownName\":\"John Doe\",\"mobile\":\"1234567890\",\"bikeNo\":\"BIKE123\",\"brand\":\"Yamaha\",\"model\":\"FZ\",\"dateOfAppointment\":\"2024-06-10\",\"description\":\"Regular servicing\"}";

        mockMvc.perform(post("/bike")
                .contentType(MediaType.APPLICATION_JSON)
                .content(bikeJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.ownName").value("John Doe"))
                .andExpect(jsonPath("$.bikeNo").value("BIKE123"));

        verify(bikeService, times(1)).bookBike(any(Bike.class));
    }

    @Test
    void testUpdateBike() throws Exception {
        when(bikeService.update(anyString(), any(Bike.class))).thenReturn(bike);

        String bikeJson = "{\"ownName\":\"John Doe\",\"mobile\":\"1234567890\",\"bikeNo\":\"BIKE123\",\"brand\":\"Yamaha\",\"model\":\"FZ\",\"dateOfAppointment\":\"2024-06-10\",\"description\":\"Regular servicing\"}";

        mockMvc.perform(put("/bike/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(bikeJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.ownName").value("John Doe"));

        verify(bikeService, times(1)).update(eq("1"), any(Bike.class));
    }

    @Test
    void testUpdateBikeNotFound() throws Exception {
        when(bikeService.update(eq("404"), any(Bike.class))).thenThrow(new bikeapplication.bike.exceptions.BikeNotFoundException("not found"));
        String bikeJson = "{\"ownName\":\"John Doe\",\"mobile\":\"1234567890\",\"bikeNo\":\"BIKE123\",\"brand\":\"Yamaha\",\"model\":\"FZ\",\"dateOfAppointment\":\"2024-06-10\",\"description\":\"Regular servicing\"}";
        mockMvc.perform(put("/bike/404")
                .contentType(MediaType.APPLICATION_JSON)
                .content(bikeJson))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetBikeById() throws Exception {
        when(bikeService.getById("1")).thenReturn(bike);

        mockMvc.perform(get("/bike/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.bikeId").value("1"))
                .andExpect(jsonPath("$.ownName").value("John Doe"));

        verify(bikeService, times(1)).getById("1");
    }

    @Test
    void testGetBikeByIdNotFound() throws Exception {
        when(bikeService.getById("404")).thenThrow(new bikeapplication.bike.exceptions.BikeNotFoundException("not found"));
        mockMvc.perform(get("/bike/404"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testDeleteBike() throws Exception {
        doNothing().when(bikeService).deleteById("1");

        mockMvc.perform(delete("/bike/1"))
                .andExpect(status().isNoContent());

        verify(bikeService, times(1)).deleteById("1");
    }

    @Test
    void testDeleteBikeNotFound() throws Exception {
        doThrow(new bikeapplication.bike.exceptions.BikeNotFoundException("not found")).when(bikeService).deleteById("404");
        mockMvc.perform(delete("/bike/404"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetAllBike() throws Exception {
        when(bikeService.getAll()).thenReturn(Arrays.asList(bike));

        mockMvc.perform(get("/bike"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bikeId").value("1"));

        verify(bikeService, times(1)).getAll();
    }

    @Test
    void testGetBikesInProcess() throws Exception {
        when(bikeService.getByInProcess()).thenReturn(Arrays.asList(bike));

        mockMvc.perform(get("/bike/in_process"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bikeId").value("1"));

        verify(bikeService, times(1)).getByInProcess();
    }

    @Test
    void testGetSuccess() throws Exception {
        when(bikeService.getSuccess()).thenReturn(Arrays.asList(bike));

        mockMvc.perform(get("/bike/success"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bikeId").value("1"));

        verify(bikeService, times(1)).getSuccess();
    }

    @Test
    void testGetHandOvered() throws Exception {
        when(bikeService.getHandOverBike()).thenReturn(Arrays.asList(bike));

        mockMvc.perform(get("/bike/handover"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bikeId").value("1"));

        verify(bikeService, times(1)).getHandOverBike();
    }

    @Test
    void testHandoverFalse() throws Exception {
        when(bikeService.getNotHandOver()).thenReturn(Arrays.asList(bike));

        mockMvc.perform(get("/bike/!handover"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bikeId").value("1"));

        verify(bikeService, times(1)).getNotHandOver();
    }

    @Test
    void testTodayAppoint() throws Exception {
        when(bikeService.getByCurrentDate()).thenReturn(Arrays.asList(bike));

        mockMvc.perform(get("/bike/today"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].bikeId").value("1"));

        verify(bikeService, times(1)).getByCurrentDate();
    }

    @Test
    void testGetBikeStatus() throws Exception {
        when(bikeService.getStatus("BIKE123")).thenReturn("bike is in process");

        mockMvc.perform(get("/bike/status/BIKE123"))
                .andExpect(status().isOk())
                .andExpect(content().string("bike is in process"));

        verify(bikeService, times(1)).getStatus("BIKE123");
    }

    @Test
    void testUpdateStatus() throws Exception {
        doNothing().when(bikeService).update(anyString(), anyString());

        mockMvc.perform(get("/bike/update/process/1"))
                .andExpect(status().isOk());

        verify(bikeService, times(1)).update("process", "1");
    }

}
