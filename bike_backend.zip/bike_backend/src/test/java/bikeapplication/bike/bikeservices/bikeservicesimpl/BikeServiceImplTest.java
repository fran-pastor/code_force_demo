package bikeapplication.bike.bikeservices.bikeservicesimpl;

import bikeapplication.bike.entities.Bike;
import bikeapplication.bike.exceptions.BikeNotFoundException;
import bikeapplication.bike.repositories.BikeRepositories;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class BikeServiceImplTest {

    @Mock
    private BikeRepositories bikeRepositories;

    @InjectMocks
    private BikeServiceImpl bikeService;

    private Bike bike;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        bike = Bike.builder()
                .bikeId("1")
                .ownName("John Doe")
                .mobile("1234567890")
                .bikeNo("BIKE123")
                .brand("Yamaha")
                .model("FZ")
                .bookAt(new Date())
                .dateOfAppointment("2024-06-10")
                .description("Regular servicing")
                .inProcess(false)
                .success(false)
                .status("wait upto 2024-06-10")
                .isHandOver(false)
                .build();
    }

    @Test
    void testBookBike() {
        when(bikeRepositories.save(any(Bike.class))).thenReturn(bike);
        Bike savedBike = bikeService.bookBike(bike);
        assertNotNull(savedBike);
        assertEquals("John Doe", savedBike.getOwnName());
        verify(bikeRepositories, times(1)).save(bike);
    }

    @Test
    void testUpdateExistingBike() {
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bike));
        when(bikeRepositories.save(any(Bike.class))).thenReturn(bike);

        Bike updateInfo = Bike.builder()
                .ownName("Jane Doe")
                .mobile("0987654321")
                .bikeNo("BIKE123")
                .brand("Honda")
                .model("CBR")
                .dateOfAppointment("2024-06-15")
                .description("Engine tuning")
                .inProcess(true)
                .success(false)
                .status("wait upto 2024-06-15")
                .isHandOver(false)
                .build();

        Bike updatedBike = bikeService.update("1", updateInfo);

        assertNotNull(updatedBike);
        assertEquals("Jane Doe", updatedBike.getOwnName());
        assertEquals("Honda", updatedBike.getBrand());
        verify(bikeRepositories).findById("1");
        verify(bikeRepositories).save(any(Bike.class));
    }

    @Test
    void testUpdateNonExistingBikeThrowsException() {
        when(bikeRepositories.findById("2")).thenReturn(Optional.empty());
        Bike updateInfo = new Bike();
        BikeNotFoundException exception = assertThrows(BikeNotFoundException.class, () -> {
            bikeService.update("2", updateInfo);
        });
        assertEquals("bike not found for given bikeId !!", exception.getMessage());
    }

    @Test
    void testGetAll() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findAll()).thenReturn(bikes);
        List<Bike> result = bikeService.getAll();
        assertEquals(1, result.size());
        verify(bikeRepositories).findAll();
    }

    @Test
    void testGetByNo() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findByBikeNo("BIKE123")).thenReturn(bikes);
        List<Bike> result = bikeService.getByNo("BIKE123");
        assertEquals(1, result.size());
        verify(bikeRepositories).findByBikeNo("BIKE123");
    }

    @Test
    void testGetByCurrentDate() {
        Bike bikeToday = Bike.builder()
                .bikeId("2")
                .dateOfAppointment(LocalDateTime.now().toLocalDate().toString())
                .inProcess(false)
                .success(false)
                .isHandOver(false)
                .build();

        List<Bike> allBikes = Arrays.asList(bike, bikeToday);
        when(bikeRepositories.findAll()).thenReturn(allBikes);

        List<Bike> result = bikeService.getByCurrentDate();
        assertNotNull(result);
        verify(bikeRepositories).findAll();
    }

    @Test
    void testGetByCurrentDateWithNonMatchingDate() {
        Bike bikeNonMatchingDate = Bike.builder()
                .bikeId("3")
                .dateOfAppointment("2099-12-31")
                .inProcess(false)
                .success(false)
                .isHandOver(false)
                .build();

        List<Bike> allBikes = Arrays.asList(bikeNonMatchingDate);
        when(bikeRepositories.findAll()).thenReturn(allBikes);

        List<Bike> result = bikeService.getByCurrentDate();
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetByCurrentDateWithInProcessOrSuccessOrHandOver() {
        Bike bikeInProcess = Bike.builder()
                .bikeId("4")
                .dateOfAppointment(LocalDateTime.now().toLocalDate().toString())
                .inProcess(true)
                .success(false)
                .isHandOver(false)
                .build();

        Bike bikeSuccess = Bike.builder()
                .bikeId("5")
                .dateOfAppointment(LocalDateTime.now().toLocalDate().toString())
                .inProcess(false)
                .success(true)
                .isHandOver(false)
                .build();

        Bike bikeHandOver = Bike.builder()
                .bikeId("6")
                .dateOfAppointment(LocalDateTime.now().toLocalDate().toString())
                .inProcess(false)
                .success(false)
                .isHandOver(true)
                .build();

        List<Bike> allBikes = Arrays.asList(bikeInProcess, bikeSuccess, bikeHandOver);
        when(bikeRepositories.findAll()).thenReturn(allBikes);

        List<Bike> result = bikeService.getByCurrentDate();
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetByOwnName() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findByOwnName("John Doe")).thenReturn(bikes);
        List<Bike> result = bikeService.getByOwnName("John Doe");
        assertEquals(1, result.size());
        verify(bikeRepositories).findByOwnName("John Doe");
    }

    @Test
    void testGetByInProcess() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findByInProcessTrue()).thenReturn(bikes);
        List<Bike> result = bikeService.getByInProcess();
        assertEquals(1, result.size());
        verify(bikeRepositories).findByInProcessTrue();
    }

    @Test
    void testGetSuccess() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findBySuccessTrue()).thenReturn(bikes);
        List<Bike> result = bikeService.getSuccess();
        assertEquals(1, result.size());
        verify(bikeRepositories).findBySuccessTrue();
    }

    @Test
    void testGetNotHandOver() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findByIsHandOverFalse()).thenReturn(bikes);
        List<Bike> result = bikeService.getNotHandOver();
        assertEquals(1, result.size());
        verify(bikeRepositories).findByIsHandOverFalse();
    }

    @Test
    void testGetHandOverBike() {
        List<Bike> bikes = Arrays.asList(bike);
        when(bikeRepositories.findByIsHandOverTrue()).thenReturn(bikes);
        List<Bike> result = bikeService.getHandOverBike();
        assertEquals(1, result.size());
        verify(bikeRepositories).findByIsHandOverTrue();
    }

    @Test
    void testGetStatusBikeFound() {
        Bike bikeInProcess = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(true)
                .success(false)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeInProcess);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        String status = bikeService.getStatus("BIKE123");
        assertEquals("bike is in process", status);
    }

    @Test
    void testGetStatusBikeDelivered() {
        Bike bikeDelivered = Bike.builder()
                .bikeNo("BIKE456")
                .inProcess(false)
                .success(false)
                .isHandOver(true)
                .build();
        List<Bike> bikes = Arrays.asList(bikeDelivered);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        String status = bikeService.getStatus("BIKE456");
        assertEquals("bike is delivered !! thank you for visiting !!", status);
    }

    @Test
    void testGetStatusBikeSuccess() {
        Bike bikeSuccess = Bike.builder()
                .bikeNo("BIKE789")
                .inProcess(false)
                .success(true)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeSuccess);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        String status = bikeService.getStatus("BIKE789");
        assertEquals("bikes servicing completed !! thank you for visiting !!", status);
    }

    @Test
    void testGetStatusBikeDefault() {
        Bike bikeDefault = Bike.builder()
                .bikeNo("BIKE000")
                .inProcess(false)
                .success(false)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeDefault);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        String status = bikeService.getStatus("BIKE000");
        assertEquals("give us 3 working days", status);
    }

    @Test
    void testGetStatusBikeNotFound() {
        when(bikeRepositories.findAll()).thenReturn(Collections.emptyList());
        String status = bikeService.getStatus("UNKNOWN");
        assertEquals("bike is not found for given bike Number please enter details again !!", status);
    }

    @Test
    void testUpdateStatus() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(false)
                .success(false)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("process", "BIKE123");
        assertTrue(bikeToUpdate.isInProcess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateStatusWithUnknownStatusType() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(false)
                .success(false)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("unknown", "BIKE123");
        verify(bikeRepositories, never()).save(any());
    }

    @Test
    void testUpdateStatusWithSuccess() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(true)
                .success(false)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("success", "BIKE123");
        assertTrue(bikeToUpdate.isSuccess());
        assertFalse(bikeToUpdate.isInProcess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateStatusWithHandover() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(false)
                .success(true)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("handover", "BIKE123");
        assertTrue(bikeToUpdate.isHandOver());
        assertFalse(bikeToUpdate.isSuccess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateStatusWithNegatedProcess() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(true)
                .success(false)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("!process", "BIKE123");
        assertFalse(bikeToUpdate.isInProcess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateStatusWithNegatedSuccess() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(false)
                .success(true)
                .isHandOver(false)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("!success", "BIKE123");
        assertFalse(bikeToUpdate.isSuccess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateStatusWithNegatedHandover() {
        Bike bikeToUpdate = Bike.builder()
                .bikeNo("BIKE123")
                .inProcess(false)
                .success(false)
                .isHandOver(true)
                .build();
        List<Bike> bikes = Arrays.asList(bikeToUpdate);
        when(bikeRepositories.findAll()).thenReturn(bikes);

        bikeService.updateStatus("!handover", "BIKE123");
        assertFalse(bikeToUpdate.isHandOver());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateWithNegatedProcess() {
        Bike bikeToUpdate = Bike.builder()
                .bikeId("1")
                .inProcess(true)
                .success(false)
                .isHandOver(false)
                .build();
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bikeToUpdate));

        bikeService.update("!process", "1");
        assertFalse(bikeToUpdate.isInProcess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateWithNegatedSuccess() {
        Bike bikeToUpdate = Bike.builder()
                .bikeId("1")
                .inProcess(false)
                .success(true)
                .isHandOver(false)
                .build();
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bikeToUpdate));

        bikeService.update("!success", "1");
        assertFalse(bikeToUpdate.isSuccess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateWithNegatedHandover() {
        Bike bikeToUpdate = Bike.builder()
                .bikeId("1")
                .inProcess(false)
                .success(false)
                .isHandOver(true)
                .build();
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bikeToUpdate));

        bikeService.update("!handover", "1");
        assertFalse(bikeToUpdate.isHandOver());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateStatusWithUnknownBikeNo() {
        when(bikeRepositories.findAll()).thenReturn(Collections.emptyList());
        bikeService.updateStatus("process", "UNKNOWN");
        verify(bikeRepositories, never()).save(any());
    }

    @Test
    void testUpdateWithStatusType() {
        Bike bikeToUpdate = Bike.builder()
                .bikeId("1")
                .inProcess(false)
                .success(false)
                .isHandOver(false)
                .build();
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bikeToUpdate));

        bikeService.update("process", "1");
        assertTrue(bikeToUpdate.isInProcess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateWithStatusTypeSuccess() {
        Bike bikeToUpdate = Bike.builder()
                .bikeId("1")
                .inProcess(true)
                .success(false)
                .isHandOver(false)
                .build();
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bikeToUpdate));

        bikeService.update("success", "1");
        assertTrue(bikeToUpdate.isSuccess());
        assertFalse(bikeToUpdate.isInProcess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateWithStatusTypeHandover() {
        Bike bikeToUpdate = Bike.builder()
                .bikeId("1")
                .inProcess(false)
                .success(true)
                .isHandOver(false)
                .build();
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bikeToUpdate));

        bikeService.update("handover", "1");
        assertTrue(bikeToUpdate.isHandOver());
        assertFalse(bikeToUpdate.isSuccess());
        verify(bikeRepositories).save(bikeToUpdate);
    }

    @Test
    void testUpdateWithStatusTypeBikeNotFound() {
        when(bikeRepositories.findById("2")).thenReturn(Optional.empty());
        BikeNotFoundException exception = assertThrows(BikeNotFoundException.class, () -> {
            bikeService.update("process", "2");
        });
        assertEquals("bike not found for given bikeId !!", exception.getMessage());
    }

    @Test
    void testGetById() {
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bike));
        Bike foundBike = bikeService.getById("1");
        assertNotNull(foundBike);
        assertEquals("John Doe", foundBike.getOwnName());
    }

    @Test
    void testGetByIdBikeNotFound() {
        when(bikeRepositories.findById("2")).thenReturn(Optional.empty());
        BikeNotFoundException exception = assertThrows(BikeNotFoundException.class, () -> {
            bikeService.getById("2");
        });
        assertEquals("bike not found for given bikeId !!", exception.getMessage());
    }

    @Test
    void testDeleteById() {
        when(bikeRepositories.findById("1")).thenReturn(Optional.of(bike));
        doNothing().when(bikeRepositories).delete(bike);
        bikeService.deleteById("1");
        verify(bikeRepositories).delete(bike);
    }

    @Test
    void testDeleteByIdBikeNotFound() {
        when(bikeRepositories.findById("2")).thenReturn(Optional.empty());
        BikeNotFoundException exception = assertThrows(BikeNotFoundException.class, () -> {
            bikeService.deleteById("2");
        });
        assertEquals("bike not found for given bikeId !!", exception.getMessage());
    }

}