package bikeapplication.bike.exceptions.handler;

import bikeapplication.bike.exceptions.BikeNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.http.converter.HttpMessageNotReadableException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;

class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler exceptionHandler;

    @BeforeEach
    void setUp() {
        exceptionHandler = new GlobalExceptionHandler();
    }

    @Test
    void testHandleBikeNotFound() {
        BikeNotFoundException ex = new BikeNotFoundException("bike not found for given bikeId !!");
        ResponseEntity<Object> response = exceptionHandler.handleBikeNotFound(ex);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertTrue(response.getBody() instanceof java.util.Map);
        java.util.Map<?, ?> body = (java.util.Map<?, ?>) response.getBody();
        assertEquals("Bike Not Found", body.get("error"));
        assertEquals("bike not found for given bikeId !!", body.get("message"));
    }

    @Test
    void testHandleMethodArgumentNotValidWithFieldError() {
        HttpHeaders headers = new HttpHeaders();
        org.springframework.http.HttpStatusCode status = HttpStatus.BAD_REQUEST;
        WebRequest request = mock(WebRequest.class);

        org.springframework.validation.BeanPropertyBindingResult bindingResult = new org.springframework.validation.BeanPropertyBindingResult(new Object(), "objectName");
        bindingResult.addError(new org.springframework.validation.FieldError("objectName", "field", "Field is invalid"));

        java.lang.reflect.Method method = GlobalExceptionHandlerTest.class.getDeclaredMethods()[0];
        org.springframework.core.MethodParameter methodParameter = new org.springframework.core.MethodParameter(method, -1);
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(methodParameter, bindingResult);

        ResponseEntity<Object> response = exceptionHandler.handleMethodArgumentNotValid(ex, headers, status, request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody() instanceof java.util.Map);
        java.util.Map<?, ?> body = (java.util.Map<?, ?>) response.getBody();
        assertEquals("Validation Failed", body.get("error"));
        assertEquals("Field is invalid", body.get("message"));
    }

    @Test
    void testHandleMethodArgumentNotValidWithoutFieldError() {
        HttpHeaders headers = new HttpHeaders();
        org.springframework.http.HttpStatusCode status = HttpStatus.BAD_REQUEST;
        WebRequest request = mock(WebRequest.class);

        org.springframework.validation.BeanPropertyBindingResult bindingResult = new org.springframework.validation.BeanPropertyBindingResult(new Object(), "objectName");

        java.lang.reflect.Method method = GlobalExceptionHandlerTest.class.getDeclaredMethods()[0];
        org.springframework.core.MethodParameter methodParameter = new org.springframework.core.MethodParameter(method, -1);
        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(methodParameter, bindingResult);

        ResponseEntity<Object> response = exceptionHandler.handleMethodArgumentNotValid(ex, headers, status, request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody() instanceof java.util.Map);
        java.util.Map<?, ?> body = (java.util.Map<?, ?>) response.getBody();
        assertEquals("Validation Failed", body.get("error"));
        assertEquals("Validation error", body.get("message"));
    }

    @Test
    void testHandleHttpMessageNotReadable() {
        HttpMessageNotReadableException ex = new HttpMessageNotReadableException(
  			  "Malformed JSON", new Throwable(), null
				);
        WebRequest request = mock(WebRequest.class);
        HttpHeaders headers = new HttpHeaders();
        org.springframework.http.HttpStatusCode status = HttpStatus.BAD_REQUEST;

        ResponseEntity<Object> response = exceptionHandler.handleHttpMessageNotReadable(ex, headers, status, request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody() instanceof java.util.Map);
        java.util.Map<?, ?> body = (java.util.Map<?, ?>) response.getBody();
        assertEquals("Malformed JSON request", body.get("error"));
        assertEquals("Malformed JSON", body.get("message"));
    }

    @Test
    void testHandleAll() {
        Exception ex = new Exception("Some error");
        ResponseEntity<Object> response = exceptionHandler.handleAll(ex);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertTrue(response.getBody() instanceof java.util.Map);
        java.util.Map<?, ?> body = (java.util.Map<?, ?>) response.getBody();
        assertEquals("Internal Server Error", body.get("error"));
        assertEquals("Some error", body.get("message"));
    }
}
