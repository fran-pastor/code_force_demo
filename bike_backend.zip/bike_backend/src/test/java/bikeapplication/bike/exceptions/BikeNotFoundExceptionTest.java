package bikeapplication.bike.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BikeNotFoundExceptionTest {
    @Test
    void testMessage() {
        BikeNotFoundException ex = new BikeNotFoundException("not found");
        assertEquals("not found", ex.getMessage());
    }
}