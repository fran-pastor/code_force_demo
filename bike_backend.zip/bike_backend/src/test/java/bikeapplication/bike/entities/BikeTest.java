package bikeapplication.bike.entities;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class BikeTest {
    @Test
    void testBuilderAndGettersSetters() {
        Date now = new Date();
        Bike bike = Bike.builder()
                .bikeId("id1")
                .ownName("Alice")
                .mobile("5551234")
                .bikeNo("B123")
                .brand("BrandX")
                .model("ModelY")
                .bookAt(now)
                .dateOfAppointment("2024-06-11")
                .description("desc")
                .inProcess(true)
                .success(false)
                .status("pending")
                .isHandOver(true)
                .build();

        assertEquals("id1", bike.getBikeId());
        assertEquals("Alice", bike.getOwnName());
        assertEquals("5551234", bike.getMobile());
        assertEquals("B123", bike.getBikeNo());
        assertEquals("BrandX", bike.getBrand());
        assertEquals("ModelY", bike.getModel());
        assertEquals(now, bike.getBookAt());
        assertEquals("2024-06-11", bike.getDateOfAppointment());
        assertEquals("desc", bike.getDescription());
        assertTrue(bike.isInProcess());
        assertFalse(bike.isSuccess());
        assertEquals("pending", bike.getStatus());
        assertTrue(bike.isHandOver());

        // Test setters
        bike.setOwnName("Bob");
        assertEquals("Bob", bike.getOwnName());
    }

    @Test
    void testNoArgsAndAllArgsConstructor() {
        Bike bike = new Bike();
        assertNull(bike.getBikeId());
        Bike bike2 = new Bike("id2", "Carol", "5556789", "B456", "BrandY", "ModelZ", new Date(), "2024-06-12", "desc2", false, true, "done", false);
        assertEquals("id2", bike2.getBikeId());
        assertEquals("Carol", bike2.getOwnName());
    }

    @Test
    void testEqualsAndHashCode() {
        Bike b1 = Bike.builder().bikeId("id3").build();
        Bike b2 = Bike.builder().bikeId("id3").build();
        assertEquals(b1, b2);
        assertEquals(b1.hashCode(), b2.hashCode());
    }

    @Test
    void testToString() {
        Bike bike = Bike.builder().bikeId("id4").ownName("Dan").build();
        String str = bike.toString();
        assertTrue(str.contains("id4"));
        assertTrue(str.contains("Dan"));
    }
}